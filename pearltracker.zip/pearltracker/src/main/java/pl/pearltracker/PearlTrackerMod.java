package pl.pearltracker;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class PearlTrackerMod implements ClientModInitializer {

    public static final List<Entry> ENTRIES = new ArrayList<>();
    private static final Map<Integer, Flying> FLYING = new HashMap<>();
    private static KeyBinding openKey;

    public static class Entry {
        public final String player;
        public final Vec3d from;
        public final Vec3d to;
        public final long time;

        Entry(String player, Vec3d from, Vec3d to) {
            this.player = player;
            this.from = from;
            this.to = to;
            this.time = System.currentTimeMillis();
        }
    }

    private static class Flying {
        String player;
        final Vec3d from;
        Vec3d last;

        Flying(String player, Vec3d from) {
            this.player = player;
            this.from = from;
            this.last = from;
        }
    }

    @Override
    public void onInitializeClient() {
        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.pearltracker.open", GLFW.GLFW_KEY_L, "category.pearltracker"));

        ClientTickEvents.END_CLIENT_TICK.register(PearlTrackerMod::tick);
        HudRenderCallback.EVENT.register((ctx, tickCounter) -> renderHud(ctx));
    }

    private static void tick(MinecraftClient mc) {
        while (openKey.wasPressed()) {
            if (mc.currentScreen == null) {
                mc.setScreen(new PearlScreen());
            }
        }

        ClientWorld world = mc.world;
        if (world == null) {
            FLYING.clear();
            return;
        }

        Set<Integer> seen = new HashSet<>();
        for (Entity e : world.getEntities()) {
            if (!(e instanceof EnderPearlEntity)) {
                continue;
            }
            EnderPearlEntity pearl = (EnderPearlEntity) e;
            int id = pearl.getId();
            seen.add(id);

            Flying f = FLYING.get(id);
            if (f == null) {
                f = new Flying(ownerName(pearl), pearl.getPos());
                FLYING.put(id, f);
                msg(mc, "\u00a7e" + f.player + " \u00a77rzucil perle z \u00a7f" + fmt(f.from));
            } else {
                f.last = pearl.getPos();
                if (f.player.equals("?")) {
                    f.player = ownerName(pearl);
                }
            }
        }

        Iterator<Map.Entry<Integer, Flying>> it = FLYING.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Flying> en = it.next();
            if (seen.contains(en.getKey())) {
                continue;
            }
            Flying f = en.getValue();
            ENTRIES.add(new Entry(f.player, f.from, f.last));
            if (ENTRIES.size() > 100) {
                ENTRIES.remove(0);
            }
            msg(mc, "\u00a7e" + f.player + " \u00a77perla wyladowala: \u00a7a" + fmt(f.last));
            it.remove();
        }
    }

    private static void renderHud(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.options.hudHidden || mc.currentScreen != null) {
            return;
        }

        int x = 6;
        int y = 6;
        long now = System.currentTimeMillis();

        for (Flying f : FLYING.values()) {
            ctx.drawTextWithShadow(mc.textRenderer,
                    "\u00a7e" + f.player + " \u00a77(w locie) \u00a7f" + fmt(f.last), x, y, 0xFFFFFF);
            y += 11;
        }

        int shown = 0;
        for (int i = ENTRIES.size() - 1; i >= 0 && shown < 5; i--) {
            Entry e = ENTRIES.get(i);
            long sec = (now - e.time) / 1000;
            if (sec > 30) {
                break;
            }
            ctx.drawTextWithShadow(mc.textRenderer,
                    "\u00a7e" + e.player + " \u00a77wyladowala \u00a7a" + fmt(e.to) + " \u00a78" + sec + "s",
                    x, y, 0xFFFFFF);
            y += 11;
            shown++;
        }
    }

    private static String ownerName(EnderPearlEntity pearl) {
        Entity owner = pearl.getOwner();
        return owner != null ? owner.getName().getString() : "?";
    }

    public static String fmt(Vec3d v) {
        return (int) Math.floor(v.x) + ", " + (int) Math.floor(v.y) + ", " + (int) Math.floor(v.z);
    }

    private static void msg(MinecraftClient mc, String s) {
        if (mc.player != null) {
            mc.player.sendMessage(Text.literal(s), false);
        }
    }
}
